Scoop
* Installing packages.
> https://scoop.sh/

---

Lua
* Optional.
> *https://www.lua.org/download.html*

---

LuaJIT (2.0.5)
* Fast Just-In-Time compiler (JIT) for Lua. **(Required)**
> *https://luajit.org/download/LuaJIT-2.0.5.zip*

---

Git
* Optional.
* For developing a custom module / script / copy of QyVern.
> *https://git-scm.com/downloads*