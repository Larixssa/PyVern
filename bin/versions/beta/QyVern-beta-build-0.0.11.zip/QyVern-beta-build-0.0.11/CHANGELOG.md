Beta Build 0.0.11

QyVern undergoes BETA.

* New open link GUI.
* Minor bugfixes.
* New library module. ``format``

That's all for the changelog.

~ Vertic, xoxo