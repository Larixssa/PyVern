#!bin/bash
clear
echo "Running QyVern..."
luajit src/main.lua