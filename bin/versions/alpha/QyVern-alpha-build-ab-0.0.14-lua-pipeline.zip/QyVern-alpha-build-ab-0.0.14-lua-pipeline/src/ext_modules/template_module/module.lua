local module = {} -- Create a name for your module

-- Add some code like functions

function module.FunctionName()
	-- Code Block
end

return module
