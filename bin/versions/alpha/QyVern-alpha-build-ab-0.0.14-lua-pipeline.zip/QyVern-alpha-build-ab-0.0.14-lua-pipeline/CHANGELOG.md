Alpha Build 0.0.14

* Updated math interface.
* -math command now shows on commands list.
* New getPi function for qymath module.
* New setup script in Lua.

That's all for the changelog.

~ Vertic, xoxo