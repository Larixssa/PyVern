Alpha Build 0.0.13

* New math interface.
* Changelog tracking.

That's all for the changelog.

~ Vertic, xoxo