-- Source: https://github.com/jonstoler/lua-snip/blob/master/math/isnan.lua

return function(n)
	return (n ~= n)
end