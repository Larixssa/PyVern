local command_properties = {}

command_properties.properties = {
	do_init = true,
	clear = false,
	show_options = false,
	show_title = false,
	show_load = false
}

return command_properties